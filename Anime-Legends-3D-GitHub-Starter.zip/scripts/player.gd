extends CharacterBody3D

@export var move_speed: float = 5.0
@export var sprint_speed: float = 7.0
@export var jump_velocity: float = 5.5
@export var attack_range: float = 2.4
@export var attack_damage: int = 25

var gravity: float = 18.0
var attack_cooldown: float = 0.0
var health: int = 100
var camera_pivot: Node3D
var camera: Camera3D
var body_mesh: MeshInstance3D
var status_label: Label

func _ready() -> void:
    add_to_group("player")
    _build_character()
    _build_camera()

func _build_character() -> void:
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    collision.shape = capsule
    add_child(collision)

    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.8
    body_mesh.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.18, 0.48, 0.92)
    mat.roughness = 0.85
    body_mesh.material_override = mat
    body_mesh.position.y = 0.9
    add_child(body_mesh)

    var hair := MeshInstance3D.new()
    var hair_mesh := SphereMesh.new()
    hair_mesh.radius = 0.34
    hair_mesh.height = 0.55
    hair.mesh = hair_mesh
    var hair_mat := StandardMaterial3D.new()
    hair_mat.albedo_color = Color(0.12, 0.08, 0.16)
    hair.material_override = hair_mat
    hair.position = Vector3(0, 1.72, 0)
    add_child(hair)

func _build_camera() -> void:
    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0, 1.1, 0)
    add_child(camera_pivot)

    camera = Camera3D.new()
    camera.position = Vector3(0, 3.2, 6.5)
    camera.rotation_degrees = Vector3(-18, 0, 0)
    camera.current = true
    camera.fov = 70
    camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = jump_velocity

    var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var cam_basis := camera_pivot.global_transform.basis
    var forward := -cam_basis.z
    var right := cam_basis.x
    var direction := (right * input_dir.x + forward * -input_dir.y)
    direction.y = 0
    direction = direction.normalized()

    var speed := sprint_speed if Input.is_action_pressed("sprint") else move_speed
    if direction.length() > 0.05:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
        body_mesh.rotation.y = atan2(direction.x, direction.z)
    else:
        velocity.x = move_toward(velocity.x, 0.0, move_speed * 7.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, move_speed * 7.0 * delta)

    move_and_slide()

    if Input.is_action_just_pressed("attack"):
        _attack()

func _attack() -> void:
    if attack_cooldown > 0.0:
        return
    attack_cooldown = 0.55
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(enemy):
            continue
        var offset: Vector3 = enemy.global_position - global_position
        if offset.length() <= attack_range:
            enemy.take_damage(attack_damage)

func take_damage(amount: int) -> void:
    health = maxi(0, health - amount)
    if health == 0:
        global_position = Vector3(0, 1, 5)
        health = 100

func get_health() -> int:
    return health
