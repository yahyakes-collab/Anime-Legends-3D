extends Control
class_name VirtualJoystick

var output: Vector2 = Vector2.ZERO
var finger_id: int = -1
var knob_radius: float = 25.0
var base_radius: float = 62.0

func _ready() -> void:
    custom_minimum_size = Vector2(150, 150)
    queue_redraw()

func _draw() -> void:
    var center := size * 0.5
    draw_circle(center, base_radius, Color(0.05, 0.08, 0.12, 0.42))
    draw_arc(center, base_radius, 0, TAU, 48, Color(0.8, 0.9, 1, 0.45), 3.0)
    draw_circle(center + output * 42.0, knob_radius, Color(0.75, 0.86, 1, 0.85))

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and finger_id == -1:
            finger_id = event.index
            _update_output(event.position)
        elif not event.pressed and event.index == finger_id:
            finger_id = -1
            output = Vector2.ZERO
            _sync_actions()
            queue_redraw()
    elif event is InputEventScreenDrag and event.index == finger_id:
        _update_output(event.position)

func _update_output(local_pos: Vector2) -> void:
    var center := size * 0.5
    output = (local_pos - center) / base_radius
    if output.length() > 1.0:
        output = output.normalized()
    _sync_actions()
    queue_redraw()

func _sync_actions() -> void:
    _set_action("move_left", output.x < -0.22)
    _set_action("move_right", output.x > 0.22)
    _set_action("move_forward", output.y < -0.22)
    _set_action("move_back", output.y > 0.22)

func _set_action(action_name: String, pressed: bool) -> void:
    if pressed:
        Input.action_press(action_name)
    else:
        Input.action_release(action_name)
