extends CharacterBody3D

var health: int = 50
var speed: float = 2.2
var gravity: float = 18.0
var attack_timer: float = 0.0

func _ready() -> void:
    add_to_group("enemies")
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.7
    collision.shape = capsule
    add_child(collision)

    var mesh_instance := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.7
    mesh_instance.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.78, 0.19, 0.22)
    mesh_instance.material_override = mat
    mesh_instance.position.y = 0.85
    add_child(mesh_instance)

func _physics_process(delta: float) -> void:
    attack_timer = maxf(0.0, attack_timer - delta)
    var player := get_tree().get_first_node_in_group("player")
    if player == null:
        return

    var offset: Vector3 = player.global_position - global_position
    offset.y = 0
    if offset.length() > 1.6 and offset.length() < 14.0:
        var dir := offset.normalized()
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        rotation.y = atan2(dir.x, dir.z)
    else:
        velocity.x = move_toward(velocity.x, 0.0, speed * 4.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, speed * 4.0 * delta)

    if not is_on_floor():
        velocity.y -= gravity * delta
    move_and_slide()

    if offset.length() < 1.7 and attack_timer <= 0.0:
        attack_timer = 1.2
        player.take_damage(8)

func take_damage(amount: int) -> void:
    health -= amount
    if health <= 0:
        queue_free()
