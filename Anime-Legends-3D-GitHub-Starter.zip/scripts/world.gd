extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const UI_SCRIPT = preload("res://scripts/game_ui.gd")

func _ready() -> void:
    _make_environment()
    _make_ground()
    _make_player()
    _make_enemies()
    var ui := CanvasLayer.new()
    ui.name = "MobileUI"
    ui.set_script(UI_SCRIPT)
    add_child(ui)

func _make_environment() -> void:
    var env := WorldEnvironment.new()
    var resource := Environment.new()
    resource.background_mode = Environment.BG_SKY
    resource.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    resource.ambient_light_color = Color(0.72, 0.79, 0.92)
    resource.ambient_light_energy = 0.7
    resource.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = resource
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -28, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = false # تعطيل الظلال لتخفيف الحمل على الهاتف
    add_child(sun)

func _make_ground() -> void:
    var body := StaticBody3D.new()
    body.name = "Ground"
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(70, 70)
    mesh.mesh = plane
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.22, 0.48, 0.29)
    mat.roughness = 1.0
    mesh.material_override = mat
    body.add_child(mesh)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(70, 0.2, 70)
    collision.shape = shape
    collision.position.y = -0.1
    body.add_child(collision)
    add_child(body)

    # صخور وأشجار بسيطة للزينة، بدون خامات أو مؤثرات ثقيلة
    for i in range(18):
        var rock := MeshInstance3D.new()
        var rock_mesh := SphereMesh.new()
        rock_mesh.radius = randf_range(0.35, 0.8)
        rock_mesh.height = rock_mesh.radius * 1.4
        rock.mesh = rock_mesh
        var rock_mat := StandardMaterial3D.new()
        rock_mat.albedo_color = Color(0.34, 0.38, 0.34)
        rock.material_override = rock_mat
        rock.position = Vector3(randf_range(-25, 25), 0.25, randf_range(-25, 25))
        add_child(rock)

func _make_player() -> void:
    var player := CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PLAYER_SCRIPT)
    player.position = Vector3(0, 1, 5)
    add_child(player)

func _make_enemies() -> void:
    for i in range(4):
        var enemy := CharacterBody3D.new()
        enemy.name = "Enemy_%d" % i
        enemy.set_script(ENEMY_SCRIPT)
        enemy.position = Vector3(-5.0 + i * 3.3, 1, -5.0 - (i % 2) * 3.0)
        add_child(enemy)
