extends CanvasLayer

const JOYSTICK_SCRIPT = preload("res://scripts/virtual_joystick.gd")

var health_label: Label
var message_label: Label

func _ready() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root)

    health_label = Label.new()
    health_label.text = "HP: 100"
    health_label.add_theme_font_size_override("font_size", 24)
    health_label.position = Vector2(24, 20)
    health_label.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(health_label)

    message_label = Label.new()
    message_label.text = "اهزم الأعداء!"
    message_label.add_theme_font_size_override("font_size", 22)
    message_label.position = Vector2(24, 54)
    message_label.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(message_label)

    var joystick := Control.new()
    joystick.name = "Joystick"
    joystick.set_script(JOYSTICK_SCRIPT)
    joystick.anchor_left = 0.0
    joystick.anchor_top = 1.0
    joystick.anchor_right = 0.0
    joystick.anchor_bottom = 1.0
    joystick.offset_left = 28
    joystick.offset_top = -180
    joystick.offset_right = 178
    joystick.offset_bottom = -30
    joystick.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(joystick)

    _add_button(root, "قفز", Vector2(-190, -160), "jump", Color(0.25, 0.65, 0.95))
    _add_button(root, "هجوم", Vector2(-105, -95), "attack", Color(0.9, 0.25, 0.25))
    _add_button(root, "ركض", Vector2(-105, -185), "sprint", Color(0.25, 0.75, 0.45))

    var refresh := Timer.new()
    refresh.wait_time = 0.15
    refresh.timeout.connect(_update_hud)
    refresh.autostart = true
    add_child(refresh)

func _add_button(parent: Control, label_text: String, bottom_right_offset: Vector2, action_name: String, tint: Color) -> void:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(78, 70)
    button.anchor_left = 1.0
    button.anchor_top = 1.0
    button.anchor_right = 1.0
    button.anchor_bottom = 1.0
    button.offset_left = bottom_right_offset.x
    button.offset_top = bottom_right_offset.y
    button.offset_right = bottom_right_offset.x + 78
    button.offset_bottom = bottom_right_offset.y + 70
    button.add_theme_font_size_override("font_size", 19)
    button.modulate = tint
    button.button_down.connect(func(): Input.action_press(action_name))
    button.button_up.connect(func(): Input.action_release(action_name))
    parent.add_child(button)

func _update_hud() -> void:
    var player := get_tree().get_first_node_in_group("player")
    if player != null:
        health_label.text = "HP: %d" % player.get_health()
    var remaining := get_tree().get_nodes_in_group("enemies").size()
    message_label.text = "الأعداء المتبقون: %d" % remaining
    if remaining == 0:
        message_label.text = "انتصرت! أحسنت!"
