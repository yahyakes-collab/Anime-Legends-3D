---
name: Feature request
about: اقتراح ميزة جديدة
title: "[FEATURE] "
labels: enhancement
---

## وصف الميزة

## لماذا نحتاجها؟

## طريقة الاستخدام المتوقعة

## ملاحظات الأداء على الهاتف
